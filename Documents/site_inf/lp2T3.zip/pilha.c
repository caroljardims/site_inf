#include <stdio.h>
#include "estruturas.h"

Pilha *cria_pilha (void)
{
    Pilha *p = (Pilha*)malloc(sizeof(Pilha));
    p->fst = NULL;
    return p;
}

void push(Pilha* p)
{
    ListaB* n = (ListaB*) malloc(sizeof(ListaB));
    
    n->prox = p->fst;
    p->fst = n;
}

void pop (Pilha* p)
{
    ListaB* t;
    
    t = p->fst;
    p->fst = t->prox;
    free(t);
}

Pilha *adicionar_bandejas(Pilha *p)
{
    int n,i;
    
    printf("\nInsira o numero de bandejas a serem adicionadas: ");
    scanf("%d", &n);
    
    for(i=0;i<n;i++)
        push(p);
        
    return p;
}

void imprime_pilha (ListaB *l)
{
    int cont=0;
    ListaB* p;
    for (p = l; p != NULL; p = p->prox)
        cont++;
    printf("\nBandejas: %d\n", cont);
}
