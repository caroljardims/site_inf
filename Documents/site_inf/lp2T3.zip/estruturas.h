typedef enum { false, true } bool;
typedef struct lista_ru{
    float tkt;
    struct lista_ru *prox;
} ListaRU;
typedef struct fila_ru{
    ListaRU *fst;
    ListaRU *end;
} Fila;
typedef struct lista_bdj{struct lista_bdj *prox;} ListaB;
typedef struct pilha_bdj{ListaB *fst;}Pilha;
typedef struct mesa{
    float ticket[10];
    int cont;
} Mesa;
