/* Criar sistema de fila do Restaurante Universitário */

#include <stdio.h>
#include <stdlib.h>
#include "estruturas.h"
#include <stdio.h>
#include "funcoes.h"

int main()
{
    Fila *ru;
    Pilha *bandeja;
    Fila *f1, *f2, *f3, *espera;
    Mesa ***mesa;
    
    int x,y,i;
    printf("\n");
    printf("Numero de linhas de mesas: ");
    scanf("%d", &x);
    printf("Numero de colunas de mesas: ");
    scanf("%d", &y);
    
    ru = cria_fila();
    bandeja = cria_pilha();
    for(i=0;i<(x*y*10);i++)
        push(bandeja);
    printf("\n%d bandejas adicionadas\n", x*y*10);
    f1 = cria_fila();
    f2 = cria_fila();
    f3 = cria_fila();
    espera = cria_fila();
    mesa = cria_mesas(mesa,x,y);
    
    printf("\nPressione ENTER para entrar no sistema...");
    getchar();getchar();
    
    sistema_controle(ru,bandeja,f1,f2,f3,espera,mesa,x,y);
    
    system("PAUSE");
    return 0;
}
