#include <stdio.h>
#include "estruturas.h"
#include "funcoes.h"

Mesa ***cria_mesas (Mesa ***matriz, int x, int y)
{
    int i,j;
    
    matriz = (Mesa***)malloc(x*sizeof(Mesa**));
     for(i=0;i<x;i++)
         matriz[i] = (Mesa**)malloc(y*sizeof(Mesa*));
     
     for(i=0;i<x;i++)
     {
          for(j=0;j<y;j++)
              matriz[i][j] = (Mesa*)malloc(sizeof(Mesa));
     }
     
     for(i=0;i<x;i++)
     {
          for(j=0;j<y;j++)
               matriz[i][j]->cont=0;
     }
    
    return matriz;
}

void insere_mesa(Mesa ***matriz, float ticket, int x, int y, Fila *espera, int *c)
{
    int i,j,k,n,op;  
    bool flag=false;
    
    system("cls");
    printf("Observe abaixo o mapa de mesas e escolha a mesa que deseja ocupar.\n");
    mostra_mesas(x,y);
    printf("\n\nMesa: ");
    scanf("%d", &n);
    
    for(i=0;i<x;i++)
    {
        for(j=0;j<y;j++)
        {
            if(n == ((i+1)*(j+1)))
            {
                if(matriz[i][j]->cont<10) 
                {
                    flag=true; 
                    k = matriz[i][j]->cont;
                    matriz[i][j]->ticket[k] = ticket;
                    matriz[i][j]->cont+=1;
                }
                else printf("\nMesa cheia.\n");
            }
        }
    }
    if(flag==false)
    {
        printf("\nDeseja (1) aguardar na fila de espera ou (2) buscar outra mesa?\n");
        scanf("%d", &op);
        while(op!=1&&op!=2)
        {
            printf("\nOpcao invalida. Digite novamente\n");
            scanf("%d", &op);
        }
        switch(op){
            case 1:
                insere_fila(espera,ticket);
                *c++;
                break;
            case 2:
                insere_mesa(matriz,ticket,x,y,espera,c);
                break;
        }
    }
}

void libera_mesa(Mesa ***matriz, int x, int y)
{
    int i,j,n;
    bool flag=false;
    
    system("cls");
    printf("Observe abaixo o mapa de mesas e escolha a mesa que deseja desocupar.");
    mostra_mesas(x,y);
    printf("Mesa: ");
    scanf("%d", &n);
    
    for(i=0;i<x;i++)
    {
        for(j=0;j<y;j++)
        {
            if(n == ((i+1)*(j+1)))
            {
                if(matriz[i][j]>0)
                {
                    flag=true;
                    matriz[i][j]->ticket[matriz[i][j]->cont] = 0;
                    matriz[i][j]->cont--;
                }
                else flag=true; printf("\nMesa vazia.\n");
            }
        }
    }
    if(flag==false) printf("\nMesa nao encontrada.\n");
}

void mostra_mesas(int x, int y)
{
    int i,j, cont=1;
    
    for(i=0;i<x;i++)
    {
        printf("\n");
        for(j=0;j<y;j++)
        {
            printf("%d\t", cont);
            cont++;
        }
    }
}


