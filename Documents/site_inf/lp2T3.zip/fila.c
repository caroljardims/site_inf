#include <stdio.h>
#include "estruturas.h"
#include "funcoes.h"

Fila *cria_fila (void)
{
    Fila *f = (Fila*)malloc(sizeof(Fila));
    f->fst = f->end = NULL;
    return f;
}

void insere_fila (Fila *f, int info)
{
    ListaRU *n = (ListaRU*) malloc(sizeof(ListaRU));
    
    system("cls");
    n->tkt = (float)info;
    printf("\nTicket %d inserido ", info);
    n->prox = NULL; 
    
    if (f->end != NULL)
        f->end->prox = n;
    else f->fst = n;
    f->end = n; 
}

void buffet(Fila *ru,Fila *f1,Fila *f2,Fila *f3,int *c1,int *c2,int *c3)
{
    float ticket;
    
    ticket = fila_retira(ru);

    if(*c1 <= *c2 && *c1 <= *c3)
    {
        insere_fila(f1,ticket); 
        *c1+=1;
        printf("no Buffet 1");     
    }
    else if(*c2 <= *c3)
    {
        insere_fila(f2,ticket); 
        *c2+=1;
        printf("no Buffet 2");     
    }
    else
    {
        insere_fila(f3,ticket); 
        *c3+=1;
        printf("no Buffet 3");     
    }
    
}

float fila_retira (Fila *f)
{
    ListaRU* t;
    float v;
    if (f->fst == NULL)
    {
        printf("\nFila vazia.\n");
        system("pause");
        exit(1);
    } /* aborta programa */
    t = f->fst;
    v = t->tkt;
    f->fst = t->prox;
    if (f->fst == NULL) f->end = NULL;
    free(t);
    return v;
}

void imprime_fila (ListaRU *l)
{
    ListaRU* p;
    for (p = l; p != NULL; p = p->prox)
        printf("%.0f\n", p->tkt);
}
