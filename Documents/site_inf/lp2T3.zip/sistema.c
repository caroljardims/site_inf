#include <stdio.h>
#include "estruturas.h"
#include "funcoes.h"

void sistema_controle(Fila *ru,Pilha *bandeja,Fila *f1,Fila *f2,Fila *f3, Fila *espera, Mesa ***mesa, int x, int y)
{
    char op;
    int cRU=1,c=0,c1=0,c2=0,c3=0,ce=0,bft; //contadores
    float tkt_mesa;
    
    do{
        mostra_menu();
        op = getchar();
        switch(op){
            case 'a':
                insere_fila(ru,cRU);
                cRU++;
                c++;
                printf("\n\nPressione ENTER para continuar...");
                getchar();getchar();
                break;
            case 'b':
                pop(bandeja);
                buffet(ru,f1,f2,f3,&c1,&c2,&c3);
                c--;
                printf("\n\nPressione ENTER para continuar...");
                getchar();getchar();
                break;
            case 'c':
                system("cls");
                bandeja = adicionar_bandejas(bandeja);
                break;
            case 'd':
                system("cls");
                printf("Pessoa de qual buffet (1 - 2 - 3 - 4[espera]) vai ocupar mesa?\n");
                scanf("%d", &bft);
                while(bft!=1&&bft!=2&&bft!=3)
                {
                    printf("Opcao invalida, digite novamente (1 - 2 - 3 - 4[espera])");
                    scanf("%d", &bft);
                }
                switch(bft){
                case 1:
                    c1--;
                    tkt_mesa = fila_retira(f1);
                    insere_mesa(mesa,tkt_mesa,x,y,espera,&ce);
                    break;
                case 2:
                    c2--;
                    tkt_mesa = fila_retira(f2);
                    insere_mesa(mesa,tkt_mesa,x,y,espera,&ce);
                    break;
                case 3:
                    c3--;
                    tkt_mesa = fila_retira(f3);
                    insere_mesa(mesa,tkt_mesa,x,y,espera,&ce);
                    break;
                case 4:
                    ce--;
                    tkt_mesa = fila_retira(espera);
                    insere_mesa(mesa,tkt_mesa,x,y,espera,&ce);
                    break;
                }
                break;
            case 'e':
                libera_mesa(mesa,x,y);
                break;
            case 'f':
                system("cls");
                estado_fila(c,ru);
                printf("\n\nPressione ENTER para continuar...");
                getchar();getchar();
                break;
            case 'g':
                system("cls");
                imprime_pilha(bandeja->fst);
                printf("\n\nPressione ENTER para continuar...");
                getchar();getchar();
                break;
            case 'h':
                system("cls");
                estado_buffet(c1,c2,c3,f1,f2,f3);
                printf("\n\nPressione ENTER para continuar...");
                getchar();getchar();
                break;
            case 'i':
                system("cls");
                estado_fila(ce,espera);
                printf("\n\nPressione ENTER para continuar...");
                getchar();getchar();
                break;
            case 'j':
                system("cls");
                estado_mesa(mesa,x,y);
                printf("\n\nPressione ENTER para continuar...");
                getchar();getchar();
                break;
        }
    }while(op!='s' && op!='S');
}

void mostra_menu(void)
{
    system("cls");
    printf("\n\tSISTEMA DE CONTROLE DO RESTAURANTE UNIVERSITARIO\n");
    printf("\n\tControle\n");
    printf("\na. Inserir pessoa na fila do restaurante");
    printf("\nb. Retirar bandeja e entrar na fila do buffet");
    printf("\nc. Repor pilha de bandejas");
    printf("\nd. Ocupar mesa");
    printf("\ne. Liberar mesa");
    printf("\n\n\tConsulta\n");
    printf("\nf. Estado da fila do RU");
    printf("\ng. Estado da pilha de bandejas");
    printf("\nh. Estados das filas de buffet");
    printf("\ni. Estado da fila de espera por mesas");
    printf("\nj. Ocupacao de mesa");
    printf("\n\nS. SAIR");
    printf("\n");
    printf("\nEscolha uma das opcoes do sistema: ");
}
