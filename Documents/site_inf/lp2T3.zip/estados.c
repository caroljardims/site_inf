#include <stdio.h>
#include "estruturas.h"
#include "funcoes.h"

void estado_fila(int c, Fila *f)
{
    printf("\nQuantidade: %d\n\nTickets:\n", c);
    imprime_fila(f->fst);
}

void estado_buffet(int c1,int c2,int c3,Fila *f1,Fila *f2,Fila *f3)
{
    printf("\n\tBuffet 1");
    estado_fila(c1,f1);
    printf("\n\tBuffet 2");
    estado_fila(c2,f2);
    printf("\n\tBuffet 3");
    estado_fila(c3,f3);
}

void estado_mesa(Mesa ***m,int x,int y)
{
    int i,j,k,l;
    
    for(i=0;i<x;i++)
    {
        for(j=0;j<y;j++)
        {
            if(m[i][j]->cont!=0)
            {
                l=m[i][j]->cont;
                printf("Tickets:");
                for(k=0;k<l;k++)
                    printf("\n%.0f ", m[i][j]->ticket[k]);
                printf("- Mesa: %d\n", (i+1)*(j+1));
            }
        }
    }     
}
