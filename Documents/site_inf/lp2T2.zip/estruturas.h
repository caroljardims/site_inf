typedef enum { false, true } bool;
typedef struct lista_aluno{
    int matricula;
    char nome[30],telefone[10];
    int crs, crt; //contadores
    struct lista_aluno *prox;
} lista_aluno;

typedef struct lista_autor{
    int cod;
    char nome[30];
    struct lista_autor *prox;
}lista_autor;

typedef struct lista_livro{
    int cod;
    struct lista_autor *aut1, *aut2;
    char titulo[30],editora[30],ano[4];
    int rsv; //reserva
    bool emp,reservado; //esprestimo
    struct lista_livro *prox;
}lista_livro;

typedef struct lista_reserva{
    lista_aluno *al;
    lista_livro *li;
    char data[10];
    struct lista_reserva *prox;
}lista_reserva;

typedef struct lista_retira{
    lista_aluno *al;
    lista_livro *li;
    char data_r[10],data_d[10];
    struct lista_retira *prox;
}lista_retira;
