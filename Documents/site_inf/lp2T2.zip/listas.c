#include <stdio.h>
#include <string.h>
#include "estruturas.h"
#include "funcoes.h"

/* Criar Listas */
lista_aluno *cria_al(void){return NULL;}
lista_autor *cria_au(void){return NULL;}
lista_livro *cria_li(void){return NULL;}
lista_reserva *cria_rs(void){return NULL;}
lista_retira *cria_rt(void){return NULL;}

/* Inserir nas Listas */

lista_aluno *insere_al(lista_aluno *lista)
{
    system("cls");
    lista_aluno *no = (lista_aluno*)malloc(sizeof(lista_aluno));
    printf("\n\tCadastro de Aluno\n");
    printf("\n");
    printf("Nome: ");
    fflush(stdin);
    gets(no->nome);
    printf("Matricula: ");
    scanf("%d",&no->matricula);
    printf("Telefone: ");
    fflush(stdin);
    gets(no->telefone);
    no->crs=0;
    no->crt=0;
    no->prox = lista;
    
    return no;
}

lista_autor *insere_au(lista_autor *lista)
{
    lista_autor *no = (lista_autor*)malloc(sizeof(lista_autor));
    printf("\n\tCadastro de Autor\n");
    printf("\nNome: ");
    fflush(stdin);
    gets(no->nome);
    printf("Codigo: ");
    scanf("%d", &no->cod);
    no->prox = lista;
    
    return no;
}

lista_livro *insere_li(lista_livro *lista, lista_autor *autor)
{
    int aut;
    char segundo;
    
    lista_livro *no = (lista_livro*)malloc(sizeof(lista_livro));
    
    system("cls");
    
    printf("\n\tCadastro de Livro\n");
    printf("\n");
    
    printf("Titulo: ");
    fflush(stdin);
    gets(no->titulo);
    
    printf("Codigo: ");
    scanf("%d",&no->cod);
   
    printf("Codigo do Autor 1: ");
    scanf("%d", &aut);
    
    no->aut1 = busca_au(autor,aut);
    
    while(no->aut1 == NULL)
    {
        printf("\nAutor nao registrado.");
        printf("\n.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.\n");
        autor = insere_au(autor);
        printf("\n.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.\n");
        printf("Codigo do Autor 1: ");
        scanf("%d", &aut);
        no->aut1 = busca_au(autor,aut);
        printf("\n");
    }
    
    printf("Este livro possui um segundo autor? (S/N): ");
    fflush(stdin);
    segundo = getchar();
    
    while(segundo!='s' && segundo!='S' && segundo!='n' && segundo!='N')
    {
        printf("\nResposta invalida. Digite S para SIM ou N para NAO");
        segundo = getchar();
    }
    
    if(segundo == 's' || segundo == 'S')
    {
        printf("Codigo do Autor 2: ");
        scanf("%d", &aut);
        no->aut2 = busca_au(autor,aut);
        while(no->aut2 == NULL)
        {
            printf("\nAutor nao registrado.");
            printf("\n.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.\n");
            autor = insere_au(autor);
            printf("\n.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.\n");
            printf("Codigo do Autor 2: ");
            scanf("%d", &aut);
            no->aut2 = busca_au(autor,aut);
            printf("\n");
        }
    }
    
    else no->aut2 = NULL;
    
    printf("Editora: ");
    fflush(stdin);
    gets(no->editora);
    printf("Ano: ");
    fflush(stdin);
    gets(no->ano);
    no->emp=false;
    no->reservado=false;
    no->rsv=0;
    no->prox = lista;
    
    imprime_li(no);
    return no;
}

lista_reserva *insere_rs(lista_reserva *lista, lista_aluno *aluno, lista_livro *livro)
{
    int cod_al, cod_li;
    
    lista_reserva *no = (lista_reserva*)malloc(sizeof(lista_reserva));
    
    system("cls");
    
    printf("\n\tReserva de Livro\n");
    printf("\n");

    printf("Codigo Aluno: ");
    scanf("%d",&cod_al);
    
    no->al = busca_al(aluno,cod_al);
    if(no->al == NULL) {printf("Aluno nao identificado.\n\n"); return NULL;}
    no->al->crs++;
    if(no->al->crs > 3)
    {
        printf("Aluno com limite de reservas esgotado.\n\n");
        return NULL;
    }
    
    printf("Codigo Livro: ");
    scanf("%d",&cod_li);
    
    no->li = busca_li(livro,cod_li);
    if(no->li == NULL) {printf("Livro nao identificado.\n\n"); return NULL;}
    livro = reserva_li(livro,cod_li);
    printf("Data: ");
    fflush(stdin);
    gets(no->data);
    
    no->prox = lista;
    
    return no;
}

lista_retira *insere_rt(lista_retira *lista, lista_aluno *aluno, lista_livro *livro, lista_reserva *reserva)
{
    int cod_al, cod_li;
    
    lista_retira *no = (lista_retira*)malloc(sizeof(lista_retira));
    
    system("cls");
    
    printf("Codigo Aluno: ");
    scanf("%d",&cod_al);
    
    no->al = busca_al(aluno,cod_al);
    if(no->al == NULL) {printf("Aluno nao identificado.\n\n"); return NULL;}
    no->al->crt++;
    if(no->al->crt > 3)
    {
        printf("Aluno com limite de emprestimos esgotado.\n\n");
        return NULL;
    }
    
    printf("Codigo Livro: ");
    scanf("%d",&cod_li);
    no->li = busca_li(livro,cod_li);
    if(no->li == NULL) {printf("Livro nao identificado.\n\n"); return NULL;}
    if(no->li->emp == true)
    {
        printf("Livro emprestado. ");
        return NULL;
    }
    
    if(no->li->rsv > 0)
    {
        no->al = reserva_al(reserva,cod_al);
        if(no->al == NULL) 
        {
            printf("Este livro possui reservas.\n\n");
            return NULL;
        }
        printf("\nLivro previamente reservado.\n\n");
        reserva = remove_rs(reserva,cod_li);
        livro = menos_reserva(livro,cod_li);
        livro = norsv_li(livro,cod_li);
    }
    
    livro = empresta_li(livro,cod_li);
    
    printf("Data de Retirada: ");
    fflush(stdin);
    gets(no->data_r);
    
    printf("Data de Devolucao: ");
    fflush(stdin);
    gets(no->data_d);
    
    no->prox = lista;
    
    imprime_li(no->li);
    return no;
}

void *devolve(lista_retira *retira, lista_aluno *aluno, lista_livro *livro)
{
    int cod_al, cod_li;
    
    lista_retira *no = (lista_retira*)malloc(sizeof(lista_retira));
    
    system("cls");
    
    printf("Codigo Aluno: ");
    scanf("%d",&cod_al);
    no->al = busca_al(aluno,cod_al);
    if(no->al == NULL) {printf("Aluno nao identificado.\n\n"); return NULL;}
    no->al->crt--;
    
    printf("Codigo Livro: ");
    scanf("%d",&cod_li);
    no->li = busca_li(livro,cod_li);
    if(no->li == NULL) {printf("Livro nao identificado.\n\n"); return NULL;}
    livro = devolve_li(livro,cod_li);
    retira = remove_rt(retira,cod_li);
}

/* Busca */

lista_autor *busca_au (lista_autor *lista, int cod)
{
    lista_autor *p;

    for (p=lista; p!=NULL; p = p->prox)
        if(p->cod == cod) return p;

    return NULL;
}

lista_aluno *busca_al (lista_aluno *lista, int cod)
{
    lista_aluno *p;

    for (p=lista; p!=NULL; p = p->prox)
        if(p->matricula == cod) return p;

    return NULL;
}

lista_livro *busca_li (lista_livro *lista, int cod)
{
    lista_livro *p;

    for (p=lista; p!=NULL; p = p->prox)
        if(p->cod == cod) return p;

    return NULL;
}

lista_livro *reserva_li (lista_livro *lista, int cod)
{
    lista_livro *p;

    for (p=lista; p!=NULL; p = p->prox)
        if(p->cod == cod){p->rsv++; p->reservado = true; return p;}

    return NULL;
}

lista_aluno *reserva_al (lista_reserva *lista, int cod)
{
    lista_reserva *b;
    lista_aluno *p;

    for (b=lista; b!=NULL; b=b->prox)
        if(b->al->matricula == cod) p = b->al; return p;

    return NULL;
}

lista_livro *menos_reserva (lista_livro *lista, int cod)
{
    lista_livro *p;

    for (p=lista; p!=NULL; p = p->prox)
        if(p->cod == cod){p->rsv--; return p;}

    return NULL;
}

lista_livro *empresta_li (lista_livro *lista, int cod)
{
    lista_livro *p;

    for (p=lista; p!=NULL; p = p->prox)
        if(p->cod == cod){p->emp=true; return p;}

    return NULL;
}

lista_livro *devolve_li (lista_livro *lista, int cod)
{
    lista_livro *p;

    for (p=lista; p!=NULL; p = p->prox)
        if(p->cod == cod){p->emp=false; return p;}

    return NULL;
}

lista_livro *norsv_li (lista_livro *lista, int cod)
{
    lista_livro *p;

    for (p=lista; p!=NULL; p = p->prox)
        if(p->cod == cod){p->reservado=false; return p;}

    return NULL;
}

/* Remo��o */

lista_livro *remove_li (lista_livro *lista, int cod)
{
    lista_livro *ant = NULL;
    lista_livro *p = lista; 

    while (p!=NULL && p->cod!=cod)
    { 
        ant=p;
        p=p->prox;
    }

    if (p == NULL) return lista;
     
    if (ant == NULL) lista = p->prox;
    else ant->prox = p->prox;
    
    free(p);
    
    return lista;
}

lista_retira *remove_rt (lista_retira *lista, int cod)
{
    lista_retira *ant = NULL;
    lista_retira *p = lista;
    
    for (p=lista; p!=NULL; p = p->prox)
        if(p->al->matricula == cod){p->li->emp=false;}

    while (p!=NULL && p->li->cod!=cod)
    { 
        ant=p;
        p=p->prox;
    }
    
    if (p == NULL) return lista;
     
    if (ant == NULL) lista = p->prox;
    else ant->prox = p->prox;
    
    free(p);
    
    return lista;
}

lista_reserva *remove_rs (lista_reserva *lista, int cod)
{
    lista_reserva *ant = NULL;
    lista_reserva *p = lista;
    
    for (p=lista; p!=NULL; p = p->prox)
        if(p->al->matricula == cod){p->al->crs--;}

    while (p!=NULL && p->li->cod!=cod)
    { 
        ant=p;
        p=p->prox;
    }
    
    if (p == NULL) return lista;
     
    if (ant == NULL) lista = p->prox;
    else ant->prox = p->prox;
    
    free(p);
    
    return lista;
}

/* Imprime Listas */

void imprime_al (lista_aluno *lista)
{
    lista_aluno *p;

    for (p=lista;p!=NULL;p=p->prox)
    {
        puts(p->nome);
    }
}

void imprime_li (lista_livro *lista)
{
    lista_livro *p;

    for (p=lista;p!=NULL;p=p->prox) puts(p->titulo);
}

void imprime_au (lista_autor *lista)
{
    lista_autor *p;

    for (p=lista;p!=NULL;p=p->prox) puts(p->nome);
}

void imprime_rs (lista_reserva *lista)
{
    lista_reserva *p;
    
    for(p=lista;p!=NULL;p=p->prox){puts(p->data);}
}
