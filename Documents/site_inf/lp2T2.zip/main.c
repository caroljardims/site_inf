#include <stdio.h>
#include <stdlib.h>
#include "estruturas.h"
#include "funcoes.h"

int main(int argc, char *argv[])
{     
    menu();
  
    system("PAUSE");	
    return 0;
}
