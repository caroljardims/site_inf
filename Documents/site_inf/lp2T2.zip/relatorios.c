#include <stdio.h>
#include <string.h>
#include "estruturas.h"
#include "funcoes.h"

void *relatorio1(lista_retira *lista)
{
    system("cls");
    
    printf("\nRELATORIO 1\n\n");
    lista_retira *p;
    int cod;
    bool flag=false;
    
    printf("Matricula Aluno: ");
    scanf("%d", &cod);
    
    for (p=lista; p!=NULL; p = p->prox)
    {
        if(p->al->matricula == cod)
        {
            flag=true;
            imprime_li(p->li);
        }
    }
    printf("\n");
    if(flag == false) printf("Emprestimo na realizado. ");
    printf("Pressione ENTER para voltar ao menu.\n");
    getchar();getchar();
}

void *relatorio2(lista_livro *lista)
{
    system("cls");
    
    printf("\nRELATORIO 2\n\n");
    lista_livro *p;
    int cod;
    bool flag=false;
    
    printf("Codigo Livro: ");
    scanf("%d", &cod);
    
    for (p=lista; p!=NULL; p = p->prox)
    {
        if(p->cod == cod)
        {
            flag=true;
            puts(p->aut1->nome);
            if(p->aut2 != NULL) puts(p->aut2->nome);
        }
    }
    printf("\n");
    if(flag == false) printf("Livro nao encontrado. ");
    printf("Pressione ENTER para voltar ao menu.\n");
    getchar();getchar();
}

void *relatorio3(lista_reserva *lista)
{
    system("cls");
    
    printf("\nRELATORIO 2\n\n");
    lista_reserva *p;
    int cod;
    bool flag=false;
    
    printf("Matricula Aluno: ");
    scanf("%d", &cod);
    
    for (p=lista; p!=NULL; p = p->prox)
    {
        if(p->al->matricula == cod)
        {
            flag=true;
            imprime_li(p->li);
        }
    }
    printf("\n");
    if(flag == false) printf("Aluno nao encontrado. ");
    printf("Pressione ENTER para voltar ao menu.\n");
    getchar();getchar();
}

void *relatorio4(lista_reserva *lista)
{
    system("cls");
    
    lista_reserva *p;

    for (p=lista; p!=NULL; p = p->prox)
        if(p->li->reservado == true) puts(p->al->nome);
    printf("Pressione ENTER para voltar ao menu.\n");
    getchar();getchar();
}

void *relatorio5(lista_livro *lista)
{
    system("cls");
     
    lista_livro *p;

    for (p=lista; p!=NULL; p = p->prox)
        if(p->emp == false) puts(p->titulo);
    printf("Pressione ENTER para voltar ao menu.\n");
    getchar();getchar();
}
