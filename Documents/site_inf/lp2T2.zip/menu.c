#include <stdio.h>
#include "estruturas.h"
#include "funcoes.h"

void menu(void)
{

    lista_aluno *aluno;
    aluno = cria_al();
    
    lista_autor *autor;
    autor = cria_au();
    
    lista_livro *livro;
    livro = cria_li();
    
    lista_reserva *reserva;
    reserva = cria_rs();
    
    lista_retira *retira;
    retira = cria_rt();
     
    char op, continua;
    int cod_li,cod_al;   
    
    do{
        mostra_menu();
        op = getchar();
        switch(op){
                   /* MENU DE CADASTRO */
            case 'a':
                 do{
                     aluno = insere_al(aluno);
                     printf("Deseja cadastrar outro aluno? (S/N): ");
                     fflush(stdin);
                     continua = getchar();
                 }while(continua == 's' || continua == 'S');
                 break;        
            case 'b':
                 do{
                     system("cls"); 
                     autor = insere_au(autor);
                     printf("Deseja cadastrar outro autor? (S/N): ");
                     fflush(stdin);
                     continua = getchar();
                 }while(continua == 's' || continua == 'S');
                 imprime_au(autor);
                 break;
            case 'c':
                 do{
                     livro = insere_li(livro,autor);
                     printf("Deseja cadastrar outro livro? (S/N): ");
                     fflush(stdin);
                     continua = getchar();
                 }while(continua == 's' || continua == 'S');
                 break;
            case 'd':
                 do{
                     reserva = insere_rs(reserva,aluno,livro);
                     imprime_rs(reserva);
                     printf("Reservar outro livro? (S/N): ");
                     fflush(stdin);
                     continua = getchar();
                 }while(continua == 's' || continua == 'S');
                 break;
                 
            case 'e':
                 do{
                     retira = insere_rt(retira,aluno,livro,reserva);
                     printf("Retirar outro livro? (S/N): ");
                     fflush(stdin);
                     continua = getchar();
                 }while(continua == 's' || continua == 'S');
                 break;
                 
            case 'f':
                 do{
                     devolve(retira,aluno,livro);
                     printf("Devolver outro livro? (S/N): ");
                     fflush(stdin);
                     continua = getchar();
                 }while(continua == 's' || continua == 'S');
                 break;
                 
                 /* MENU DE RELAT�RIOS */
            case '1':
                relatorio1(retira);
                break;
            case '2':
                relatorio2(livro);
                break;
            case '3':
                relatorio3(reserva);
                break;
            case '4':
                relatorio4(reserva);
                break;
            case '5':
                relatorio5(livro);
                break;
        }
    }while(op!='s' && op!='S');  

}

void mostra_menu(void)
{
    system("cls");
    printf("\n\t\tMENU DE CADASTRO\n");
    printf("\n\ta. Cadastrar Aluno");
    printf("\n\tb. Cadastrar Autor");
    printf("\n\tc. Cadastrar Livro");
    printf("\n\td. Efetuar Reserva");
    printf("\n\te. Retirar Livro");
    printf("\n\tf. Devolver Livro");
    printf("\n");
    printf("\n\t\tMENU DE RELATORIOS\n");
    printf("\n\t1. Livros Emprestados");
    printf("\n\t2. Autor(es) do Livro");
    printf("\n\t3. Livros Reservados");
    printf("\n\t4. Fila de Espera");
    printf("\n\t5. Livros Disponiveis");
    printf("\n");
    printf("\n\t'S' para Sair do programa");
    printf("\n");
    printf("\n  Escolha uma opcao: ");
}
