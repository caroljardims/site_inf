#include <stdio.h>
#include <stdlib.h>
#include "dijkstra.h"
#define NODE 8

int main( )
{
    graph *g = creategraph(NODE);
    float menor_caminho;
    int a,b;

    insertedg(g, 0, 1,0.1);
    insertedg(g, 0, 4,2.1);
    insertedg(g, 0, 5,1.1);
    insertedg(g, 1, 0,1.2);
    insertedg(g, 1, 2,2.2);
    insertedg(g, 1, 6,1.3);
    insertedg(g, 2, 1,0.2);
    insertedg(g, 2, 3,0.3);
    insertedg(g, 3, 2,1.4);
    insertedg(g, 3, 4,0.4);
    insertedg(g, 3, 6,2.3);
    insertedg(g, 3, 7,0.5);
    insertedg(g, 4, 3,1.5);
    insertedg(g, 4, 5,0.6);
    insertedg(g, 4, 0,2.4);
    insertedg(g, 5, 4,0.7);
    insertedg(g, 5, 0,1.6);
    insertedg(g, 6, 3,2.5);
    insertedg(g, 6, 7,0.8);
    insertedg(g, 6, 1,1.7);
    insertedg(g, 7, 6,0.9);
    insertedg(g, 7, 3,1.0);
    
    printf ("\nImprimindo grafo\n\n");
    print_graph(g);
    
    printf("\nEscolha o primeiro ponto de 1 a 8: ");
    scanf("%d",&a);
    printf("\nEscolha o segundo ponto de 1 a 8: ");
    scanf("%d",&b);
    
    menor_caminho = dijkstra(g,NODE,a-1,b-1);
    if(menor_caminho == 0) printf("\n\nEste caminho nao existe\n\n");
    else
        printf("\n\nMENOR CAMINHO: %.1f unidades de distancia.\n\n", menor_caminho);

    system("PAUSE");
    return 0;
}
