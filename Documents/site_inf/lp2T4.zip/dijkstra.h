#include "grafo.h"
#define INFINITO 99999999

float dijkstra(graph *grafo, int tamanho, int inicio, int destino){

    int i,j,prox,t=tamanho;
    bool flag=false, achou = false;
    float menor,caminho=0,aux_menor;
    graph *d = creategraph(tamanho);

    for(i=0;i<tamanho;i++)
    {
        d->visited[i] = openned;
        for(j=0;j<tamanho;j++)
        {
            d->m[i][j] = grafo->m[i][j];
            d->value[i][j] = INFINITO;
        }
    }

    i=inicio;
    do
    {
        d->visited[i] = current;
        menor=INFINITO;
        printf("\n\n    ATUAL (%d) ", i+1);
        for(j = 0; j < d->tam; j++)
        {
            if(d->m[i][j])
            {
                if(d->m[i][j] < 0) return 0;
                if(d->visited[j] == openned)
                {
                    d->value[i][j] = grafo->value[i][j];
                    if(j == destino && !achou)
                    {
                        printf("\nVISITADO (%d)", j+1);
                        aux_menor = caminho + d->value[i][j];
                        achou = true;
                    }
                    if(d->value[i][j] <= menor)
                    {
                        menor = d->value[i][j];
                        prox=j;
                    }
                    printf("\nVISITADO (%d)", j+1);
                }
            }
        }
        d->visited[i] = closed;
        printf("\nFECHADO (%d)", i+1);
        i=prox;
        if(menor != INFINITO) caminho+=menor;
        if(prox==destino) flag = true;
        t--;
    }while(!flag && t > 0);
    if(aux_menor < caminho) caminho = aux_menor;
    
    if(flag) return caminho;
    else return 0;
    
}
