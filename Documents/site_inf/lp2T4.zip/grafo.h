#define MAX 1000

typedef enum {false,true}bool;
typedef enum {openned,current,closed}state;
typedef struct graph{
    bool m[MAX][MAX];
    float value[MAX][MAX];
    state visited[MAX];
    int tam;
}graph;

graph *creategraph(int tamanho){
    int i,j;
    graph* g = (graph*) malloc(sizeof(graph));
    g->tam = tamanho;
    for(i = 0; i < tamanho; i++)
    {
        for(j = 0; j < tamanho; j++)
        {
            g->m[i][j] = 0;
            g->value[i][j] = 0;
        }
    }
    return g;
}

void print_graph(graph* g){
    int i,j;
    for(i = 0; i < g->tam; i++){
        printf(" (%d)", i+1);
        for(j = 0; j < g->tam; j++){
            if(g->m[i][j]) printf(" |--%.1f--> (%d)", g->value[i][j], j+1);
        }
        printf("\n");
    }
}

void insertedg(graph *g, int v1, int v2, float value){
    g->m[v1][v2] = true;
    g->value[v1][v2] = value;
}

void removeedg(graph* g, int v1, int v2){
    g->m[v1][v2] = false;
}

bool existedg(graph *g, int v1, int v2){
    return g->m[v1][v2] ;
}
