#include <stdio.h>
#include <string.h>
#include "paciente.h"
#include "funcoes.h"

void ler_dimensao(int *x, int *y)
{
     printf("Insira o numero de pacientes: ");
     scanf("%d",x);
     
     printf("Insira o numero de meses: ");
     scanf("%d",y);
}

void cadastrar_paciente(struct paciente *atual)
{    
     printf("Informe o CPF: ");
     fflush(stdin);
     gets(atual->CPF);
     
     printf("Informe o nome da pessoa: ");
     fflush(stdin);
     gets(atual->nomePessoa);
     
     printf("Informe o sexo (M/F): ");
     scanf(" %c", &atual->sexo);
     
     while(atual->sexo != 'm' && atual->sexo != 'M' && atual->sexo != 'f' && atual->sexo != 'F')
     {
          printf("Valor invalido! Informe M para masculino ou F para feminino: ");
          scanf(" %c", &atual->sexo);
     }       
}

void resultado_exame(struct paciente *resultado)
{
     printf("Informe a quantidade de Eritrocitos: ");
     scanf("%f", &resultado->qtidadeEritrocitos);
     
     while(resultado->qtidadeEritrocitos < 0)
     {
          printf("Valor invalido! A quantidade de Eritrocitos nao pode ser negativa. ");
          printf("\nDigite novamente a quantidade de Eritrocitos ");
          scanf("%f", &resultado->qtidadeEritrocitos);
     }
     
     printf("Informe a quantidade de Plaquetas: ");
     scanf("%d", &resultado->plaquetas);
     
     while(resultado->plaquetas < 0)
     {
          printf("Valor invalido! A quantidade de Plaquetas nao pode ser negativa. ");
          printf("\nDigite novamente a quantidade de Plaquetas ");
          scanf("%d", &resultado->plaquetas);
     }
     
     printf("Informe a quantidade de Leucocitos: ");
     scanf("%d", &resultado->leucocitos);
     
     while(resultado->leucocitos < 0)
     {
          printf("Valor invalido! A quantidade de Leucocitos nao pode ser negativa. ");
          printf("\nDigite novamente a quantidade de Leucocitos ");
          scanf("%d", &resultado->leucocitos);
     }
     
     printf("Informe a quantidade de Hemoglobina: ");
     scanf("%f", &resultado->hemoglobina);
     
     while(resultado->hemoglobina < 0)
     {
          printf("Valor invalido! A quantidade de Hemoglobina nao pode ser negativa. ");
          printf("\nDigite novamente a quantidade de Hemoglobina ");
          scanf("%f", &resultado->hemoglobina);
     }
     
     printf("Observacoes: ");
     getchar();
     scanf("%[^\n]s", &resultado->observacoes);
}

int mostramenu()
{
     int menu;

     printf("\n\tMENU\n\n");
     printf("\n1. Relatorio 1");
     printf("\n2. Relatorio 2");
     printf("\n3. Relatorio 3");
     printf("\n4. Relatorio 4");
     printf("\n5. Relatorio 5");
     printf("\n6. Relatorio 6");
     printf("\n7. Relatorio 7");
     printf("\n8. Relatorio 8");
     printf("\n9. Relatorio 9");
     printf("\n10. Relatorio 10");
     printf("\n11. Sair");
     
     printf("\n\nEscolha uma opcao do Menu: ");
     scanf("%d", &menu);
     
     return menu;
}

float comparar(struct paciente** matriz, int y)
{
     int i;
     float media=0;
     
     for(i=0;i<y;i++)
         media += matriz[i]->qtidadeEritrocitos;
         
     return media/=i;
}
