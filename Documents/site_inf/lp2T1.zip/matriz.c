#include "paciente.h"
#include "funcoes.h"
#include <string.h>

void gerar_matriz(struct paciente*** matriz, int x, int y)
{     
     int i,j;
     matriz = (struct paciente***)malloc(x*sizeof(struct paciente**));
     for(i=0;i<x;i++)
         matriz[i] = (struct paciente**)malloc(y*sizeof(struct paciente*));
     
     for(i=0;i<x;i++)
     {
          for(j=0;j<y;j++)
              matriz[i][j] = (struct paciente*)malloc(sizeof(struct paciente));
     }
     
     for(i=0;i<x;i++)
     {
          printf("\n");
          cadastrar_paciente(matriz[i][0]);
          for(j=0;j<y;j++)
          {
               resultado_exame(matriz[i][j]);
          }
     }
     
     printf("\nMatriz gerada com sucesso!");
     
     printf("\nPressione ENTER para ver o cadastro de pacientes...");
     getchar();getchar();
     system("cls");
     mostrar_matriz(matriz,x,y);
     
     printf("\nPressione ENTER para ver o MENU de Relatorios...");
     getchar();
     system("cls");
     gerar_relatorios(matriz,x,y);
}

void mostrar_matriz(struct paciente*** matriz, int x, int y)
{
     int i,j;

     for(i=0;i<x;i++)
     {
          printf("\n\tPaciente %d\n", i+1);
          
          printf("\nCPF: %s", matriz[i][0]->CPF);
          printf("\nNome: %s", matriz[i][0]->nomePessoa);
          if(matriz[i][0]->sexo == 'm' || matriz[i][0]->sexo == 'M')
              printf("\nSexo: Masculino");
          else
              printf("\nSexo: Feminino");

          for(j=0;j<y;j++)
          {
               printf("\n\nMes %d\n", j+1);
               printf("\nQuantidade Eritrocitos: %.1f", matriz[i][j]->qtidadeEritrocitos);
               printf("\nPlaquetas: %d", matriz[i][j]->plaquetas);
               printf("\nLeucocitos: %d", matriz[i][j]->leucocitos);
               printf("\nHemoglobina: %.1f", matriz[i][j]->hemoglobina);
               printf("\nObservacoes: %s\n", matriz[i][j]->observacoes);
          }
     }
}
