#include <stdio.h>
#include <stdlib.h>
#include "paciente.h"
#include "funcoes.h"

int main()
{
  struct paciente*** matriz;
  
  int x,y;
  
  ler_dimensao(&x,&y);
  
  gerar_matriz(matriz,x,y);
  
  free(matriz);

  system("PAUSE");	
  
  return 0;
}
