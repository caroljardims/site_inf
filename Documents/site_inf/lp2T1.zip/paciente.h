struct paciente
{
     char CPF[12];
     char nomePessoa[81];
     char sexo;
     float qtidadeEritrocitos;
     int plaquetas;
     int leucocitos;
     float hemoglobina;
     char observacoes[100];
};
