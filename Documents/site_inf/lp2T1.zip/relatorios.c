#include <string.h>
#include "paciente.h"
#include "funcoes.h"

void gerar_relatorios(struct paciente*** matriz, int x, int y)
{
     int menu;
     do
     {
          menu = mostramenu();
          
          switch(menu)
        {
            case 1:
                relatorio_1(matriz,x,y);
                break;
            case 2:
                relatorio_2(matriz,x,y);
                break;
            case 3:
                relatorio_3(matriz,x,y);
                break;
            case 4:
                relatorio_4(matriz,x,y);
                break;
            case 5:
                relatorio_5(matriz,x,y);
                break;
            case 6:
                relatorio_6(matriz,x,y);
                break;
            case 7:
                relatorio_7(matriz,x,y);
                break;
            case 8:
                relatorio_8(matriz,x,y);
                break;
            case 9:
                relatorio_9(matriz,x,y);
                break;
            case 10:
                relatorio_10(matriz,x,y);
                break;
        }
          
     }while(menu!=11);
     
}

void relatorio_1(struct paciente*** matriz, int x, int y)
{
     char CPF[12];
     int i,j,flag=0;
     float media;
     
     printf("Insira o CPF: ");
     scanf("%s", &CPF);
     
     for(i=0;i<x;i++)
     {
          if(strcmp(matriz[i][0]->CPF,CPF) == 0)
          {
               flag=1;
               media=comparar(matriz[i],y);
               break;
          }
     }
     if(flag==1)
         printf("\nMedia de Eritrocitos: %.1f\n", media);
     else
         printf("\nCPF nao encontrado.\n");
}

void relatorio_2(struct paciente*** matriz, int x, int y)
{
     int i,j,maior=0;
     char nome[81];
     
     printf("\nPaciente que registrou maior numero de plaquetas: ");
     
     for(i=0;i<x;i++)
     {
          for(j=0;j<y;j++)
          {
               if(matriz[i][j]->plaquetas > maior)
               {
                    maior=matriz[i][j]->plaquetas;
                    strcpy(nome,matriz[i][0]->nomePessoa);
               }
          }
     }
     printf("%s\n",nome);
}

void relatorio_3(struct paciente*** matriz, int x, int y)
{
     int i,j,media[x];
     
     for(i=0;i<x;i++)
         media[i]=0;
     
     printf("\nLista de Pacientes com Media de Leucocitos superior a 5000\n");
     
     for(i=0;i<x;i++)
     {
          for(j=0;j<y;j++)
               media[i]+=matriz[i][j]->leucocitos;

          media[i]/=j;

          if(media[i] > 5000) printf("\n   %s\n", matriz[i][0]->nomePessoa);
     }
}

void relatorio_4(struct paciente*** matriz, int x, int y)
{
     int i=0,j,contador=0,flag;
     
     printf("\nQuantidade de pacientes que apresentaram hemoglobina inferior a 10: ");
     
     do
     {
         flag=0;
         for(j=0;j<y;j++)
         {
              if(matriz[i][j]->hemoglobina < 10)
              {
                   flag=1;
                   contador++;
              }
              if(flag == 1) i++;
         }
         if(flag==0) i++;
     }while(i<x);
     
     printf("%d\n", contador);
}

void relatorio_5(struct paciente*** matriz, int x, int y)
{
     int i,j,media_total[x],media=0,media_paciente[x],contador=0,flag;
     
     for(i=0;i<x;i++) 
     {
          media_total[i]=0;
          media_paciente[i]=0;
     }
     
     for(i=0;i<x;i++)
     {
          for(j=0;j<y;j++)
          {
               media_total[i]+=matriz[i][j]->plaquetas;
               media_paciente[i]+=matriz[i][j]->plaquetas;       
          }
          media_total[i]/=j;
          media_paciente[i]/=j;
     }
     
     for(i=0;i<x;i++) media+=media_total[i];
     media/=i;
     
     i=0;
     do
     {
          flag=0;
          for(j=0;j<y;j++)
          {
               if(media_paciente[i] > media)
               {
                    flag=1;
                    contador++;
               }
               if(flag==1) i++;
          }
          if(flag==0) i++;
     }while(i<x);
     
     printf("\n%d pacientes apresentaram media superior de plaquetas.\n", contador);
}

void relatorio_6(struct paciente*** matriz, int x, int y)
{
     int mes,i;
     
     printf("\n\nInforme o mes: ");
     scanf("%d", &mes);
     
     while(mes<0 && mes>y)
     {
          printf("\n\nMes indisponivel. Insira um mes de 1 a %d: ", y);
          scanf("%d", &mes);
     }
     
     printf("\n\nLista de Pacientes com Suspeita de Anemia\n\n");
     
     for(i=0;i<x;i++)
     {
          if(matriz[i][mes]->hemoglobina < 10 && matriz[i][mes]->qtidadeEritrocitos < 3000000)
          printf("%s\n", matriz[i][0]->nomePessoa);
     }     
}

void relatorio_7(struct paciente*** matriz, int x, int y)
{
     int i=0,j,flag=0;
     
     printf("\n\nMulheres com Acentuada Anisocitose:\n");
     
     do
     {
          flag=0;
          for(j=0;j<y;j++)
          {
               if(matriz[i][0]->sexo == 'f' || matriz[i][0]->sexo == 'F')
               {
                    if(matriz[i][j]->leucocitos > 10000 && strcmp(matriz[i][j]->observacoes,"acentuada anisocitose") == 0)
                    {
                         printf("%s\n", matriz[i][0]->nomePessoa);
                         flag=1;
                    }
               }
               
               if(flag==1) i++;
          }
          if(flag==0) i++;
     }while(i<x);
}

void relatorio_8(struct paciente*** matriz, int x, int y)
{
     int i,j;
     struct paciente aux[x];
     char temp[81];
     
     printf("\n\nLista de nomes em Ordem Alfabetica\n\n");
     
     for(i=0;i<x;i++)
         strcpy(aux[i].nomePessoa,matriz[i][0]->nomePessoa);
         
     for(i=0;i<x;i++)
     {
          for(j=i+1;j<x;j++)
          {
               if(strcmp(aux[i].nomePessoa,aux[j].nomePessoa) > 0)
               { 
                    strcpy(temp,aux[i].nomePessoa);
                    strcpy(aux[i].nomePessoa,aux[j].nomePessoa);
                    strcpy(aux[j].nomePessoa,temp);
               }
          }
     }
          
     for(i=0;i<x;i++)
         printf("%s\n", aux[i].nomePessoa);
}

void relatorio_9(struct paciente*** matriz, int x, int y)
{
     int i,j,menor,flag=0;

     printf("\n\nMenor valor de leucocitos em homens: ");
     
     for(i=0;i<x;i++)
     {
          for(j=0;j<y;j++)
          {
               if(matriz[i][j]->sexo == 'm' || matriz[i][j]->sexo == 'M')
               {
                   flag=1;
                   menor = matriz[i][j]->leucocitos;
                   break;
               }
          }
     }
     
     if(flag == 1)
     {
          for(i=0;i<x;i++)
         {
              for(j=0;j<y;j++)
              {
                   if(matriz[i][j]->sexo == 'm' || matriz[i][j]->sexo == 'M')
                   {
                        flag=1;
                        if(matriz[i][j]->leucocitos < menor) menor = matriz[i][j]->leucocitos;
                   }
              }
          }
          printf("%d\n", menor);
     }

     else printf("\nNao ha pacientes homens cadastrados.\n");
}

void relatorio_10(struct paciente*** matriz, int x, int y)
{
     int i,j;
     
     printf("\n\nLista de pacientes que apresentaram aumento de Leucocitos em tres meses consecutivos\n");
     for(i=0;i<x;i++)
     {
          for(j=0;j<y-3;j++)
          {
               if(matriz[i][j]->leucocitos < matriz[i][j+1]->leucocitos)
               {
                    if(matriz[i][j+1]->leucocitos < matriz[i][j+2]->leucocitos)
                    {
                         if(matriz[i][j+2]->leucocitos < matriz[i][j+3]->leucocitos)
                             printf("   %s\n", matriz[i][0]->CPF);
                    }
               }
               
          }
     }
}
