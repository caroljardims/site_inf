
import java.io.Serializable;



public class Usuario implements Serializable {

    private final String nome;
    private final String norg;
    private String fone;
    private final String mail;
    private final String user;
    private final String pass;
    private int ag_hora;
    private int ag_minuto;

    public Usuario(String nome, String norg, String fone, String mail, String user, String pass) {

        this.nome = nome;
        this.norg = norg;
        this.mail = mail;
        this.user = user;
        this.pass = pass;
    }

    public String getNome() { return nome;}

    public String getNorg() { return norg;}

    public String getFone() { return fone;}

    public String getMail() { return mail;}
    
    public void setAgHora(int hora) {
        this.ag_hora = hora;
    }
    
    public void setAgMinuto(int minuto) {
        this.ag_minuto = minuto;
    }
    
    public Usuario logar(String user, String pass) {

        if(this.user.equals(user)&&this.pass.equals(pass))
            return this;
        else
            return null;
    }
}
