

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.StringTokenizer;


public class WebSome {
    
    ////////////////////////////////////////////
    // Atributos e métodos de persistência. //
    ////////////////////////////////////////////
    
    public PerfilDeAgendamento pa;
    public ArrayList<Usuario> users;
    public ArrayList<Atendente> attes;
    public ArrayList<Agendamento> agenda;
    
    public WebSome () throws Exception {
        FileInputStream fis;
        try {
            fis = new FileInputStream("db_pa");
            ObjectInputStream ois = new ObjectInputStream(fis);
            pa = (PerfilDeAgendamento) ois.readObject();
            ois.close();
        } catch (FileNotFoundException ex) {
            pa = new PerfilDeAgendamento();
        }
        
        try {
            fis = new FileInputStream("db_users");
            ObjectInputStream ois = new ObjectInputStream(fis);
            users = (ArrayList<Usuario>) ois.readObject();
            ois.close();
        } catch (FileNotFoundException ex) {
            users = new ArrayList<Usuario>();
        }
        
        try {
            fis = new FileInputStream("db_attes");
            ObjectInputStream ois = new ObjectInputStream(fis);
            attes = (ArrayList<Atendente>) ois.readObject();
            ois.close();
        } catch (FileNotFoundException ex) {
            attes = new ArrayList<Atendente>();
        }
        
        try {
            fis = new FileInputStream("db_agenda");
            ObjectInputStream ois = new ObjectInputStream(fis);
            agenda = (ArrayList<Agendamento>) ois.readObject();
            ois.close();
        } catch (FileNotFoundException ex) {
            agenda = new ArrayList<Agendamento>();
        }
    }
    
    public void savePa () throws Exception {
        FileOutputStream fos = new FileOutputStream("db_pa");
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        oos.writeObject(pa);
        oos.close();
    }

    public void saveUsers () throws Exception {
        FileOutputStream fos = new FileOutputStream("db_users");
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        oos.writeObject(users);
        oos.close();
    }

    public void saveAttes () throws Exception {
        FileOutputStream fos = new FileOutputStream("db_attes");
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        oos.writeObject(attes);
        oos.close();
    }
    
    public void saveAgenda () throws Exception {
        FileOutputStream fos = new FileOutputStream("db_agenda");
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        oos.writeObject(agenda);
        oos.close();
    }

    @SuppressWarnings("null")
    public static void main(String args[]) throws Exception {

    WebSome ws = new WebSome();
    
    Usuario usuario = null;
    
    Atendente atendente = null;
    
    String nome, norg, fone, mail, user, pass;
    
    String inim, endm, init, endt, temp;
    
    int idat = 0; boolean comp = false; String obat = null;
    
    int dia=1, mes=1, hora = ws.pa.getMih(), minuto = ws.pa.getMim(), dur = ws.pa.getAdm();
    int n_att = ws.attes.size(), att_time = 0;
    
    String requestMessageLine;
    String webPage = "index.html";
    int state = 10;

    String admPageIni =
        "<!DOCTYPE html><html><head><meta charset=\"UTF-8\"/>" +
        "<title>Java Web Server</title><script>function clear(){" +
        "history.replaceState({},\"Java Web Server\",\"/\");}</script>" +
        "</head><body onload=\"clear()\"><h1>Painel administrativo.</h1>";
    String admPageEnd =
        "<form name=\"input\" action=\"\" method=\"get\">" +
        "Turno da manhã (horas): (Ex: \"08:00\")<br>Início:<input type=\"text\" name=\"inim\">" +
        "Fim:<input type=\"text\" name=\"endm\"><br>" +
        "Turno da tarde (horas): (Ex: \"14:00\")<br>Início:<input type=\"text\" name=\"init\">" +
        "Fim:<input type=\"text\" name=\"endt\"><br>" +
        "Atendimento (minutos): (Ex: \"30\")<br>Duração:<input type=\"text\" name=\"temp\"><br>" +
        "<input type=\"submit\" value=\"Redefinir perfil de atendimento\">" +
        "</form><br><form name=\"input\" action=\"\" method=\"get\">" +
        "Novo atendente:<br>Nome:<input type=\"text\" name=\"anom\"><br>" +
        "Código:<input type=\"text\" name=\"acod\"><br>" +
        "Usuário:<input type=\"text\" name=\"ause\"><br>" +
        "Senha:<input type=\"password\" name=\"apas\"><br>" +
        "<input type=\"submit\" value=\"Cadastrar atendente\">" +
        "<a href=\"?back\" style=\"text-decoration: none\">" +
        "<input type=\"button\" value=\"Voltar\"></a></form></body></html>";
    
    String usrPageIni =
        "<!DOCTYPE html><html><head><meta charset=\"UTF-8\"/>" +
        "<title>Java Web Server</title><script>function clear(){" +
        "history.replaceState({},\"Java Web Server\",\"/\");}</script>" +
        "</head><body onload=\"clear()\"><h1>Painel do usuário.</h1>";
    String usrPageEnd =
        "</form><a href=\"?okay\" style=\"text-decoration: none\">" +
        "<input type=\"button\" value=\"Marcar\"></a>" +
        "<a href=\"?back\" style=\"text-decoration: none\">" +
        "<input type=\"button\" value=\"Voltar\"></a></form></body></html>";
    
    String okaPageIni =
        "<!DOCTYPE html><html><head><meta charset=\"UTF-8\"/>" +
        "<title>Java Web Server</title><script>function clear(){" +
        "history.replaceState({},\"Java Web Server\",\"/\");}</script>" +
        "</head><body onload=\"clear()\"><h1>Atendimento marcado.</h1>";
    String okaPageEnd =
        "</form><a href=\"?back\" style=\"text-decoration: none\">" +
        "<input type=\"button\" value=\"Voltar\"></a>" +
        "<a href=\"javascript:window.print()\" style=\"text-decoration: none\">" +
        "<input type=\"button\" value=\"Imprimir\"></a></form></body></html>";
    
    String attPageIni =
        "<!DOCTYPE html><html><head><meta charset=\"UTF-8\"/>" +
        "<title>Java Web Server</title><script>function clear(){" +
        "history.replaceState({},\"Java Web Server\",\"/\");}</script>" +
        "</head><body onload=\"clear()\"><h1>Painel do atendente.</h1>";
    String attPageEnd =
        "</form><br><form name=\"input\" action=\"\" method=\"get\">" +
        "Código do atendimento:<input type=\"text\" name=\"idat\"><br>" +
        "O usuário compereceu: <input type=\"radio\" name=\"comp\" value=\"sim\" checked>Sim" +
        "<input type=\"radio\" name=\"comp\" value=\"nao\">Não <br>" +
        "Observação:<input type=\"text\" name=\"obat\"><br>" +
        "<input type=\"submit\" value=\"Registrar atendimento\">" +
        "<a href=\"?back\" style=\"text-decoration: none\">" +
        "<input type=\"button\" value=\"Voltar\"></a></form></body></html>";
    
    int myPort = 6789;

    ServerSocket listenSocket = new ServerSocket (myPort);
    System.out.println("> Servidor iniciado na porta: "+ myPort);

    while(true) {

        System.out.println("> Esperando requisições...");
            Socket connectionSocket = listenSocket.accept();

        BufferedReader inFromClient = new BufferedReader (
            new InputStreamReader(connectionSocket.getInputStream()));

        DataOutputStream outToClient = new DataOutputStream (
            connectionSocket.getOutputStream());

        requestMessageLine = inFromClient.readLine();
        System.out.println("> Requisição: "+ requestMessageLine);
            
        requestMessageLine = requestMessageLine.replaceAll("&", " ");

        StringTokenizer tokenizedLine = new StringTokenizer(requestMessageLine);

        String token = "";
        
        if(tokenizedLine.nextToken().equals("GET"))
            token = tokenizedLine.nextToken();
        if(token.startsWith("/") == true)
            token = token.substring(1);

        PrintWriter writer = new PrintWriter("page.html", "UTF-8");

        switch(state) {

            case 10:
                webPage = "index.html";
                state = 11;
                break;

            case 11:
                if(token.startsWith("?newa") == true) {
                    webPage = "newaccount.html";
                    state = 30;
                    break;
                }
 
                if(token.startsWith("?user=") == true){
                    user = token.substring(6);
                    token = tokenizedLine.nextToken();
                    pass = token.substring(5);

                    if(user.equals("admin")&&pass.equals("admin")) {
                        writer.write(admPageIni);
                        writer.write("<p>Perfil de atendimento atual:</p>"+ws.pa.toString());
                        writer.append(admPageEnd);
                        webPage = "page.html";
                        state = 12;
                        break;
                    }
                    
                    for(Usuario este : ws.users) {
                        usuario = este.logar(user, pass);
                        
                        if(usuario!=null){
                            writer.write(usrPageIni);
                            
                            writer.write("<h2>"+ este.getNome().toUpperCase() +"</h2>");
                            
                            if(ws.attes.isEmpty())
                                writer.write("<p>Não há atendentes disponíveis</p>");
                            
                            else{
                                Atendente atend = ws.attes.get(0);
                                for(int i=0;i<ws.attes.size()-1;i++){
                                    if(ws.attes.get(i).getAtendimentos() > ws.attes.get(i+1).getAtendimentos())
                                        atend= ws.attes.get(i+1);                           
                                }
                                
                                if(ws.agenda.isEmpty()) {
                                    writer.write("<p>Dia " + 2 + "/" + 1 
                                                + " às " + ws.pa.getMih() + ":" + ws.pa.getMim() + "</p>");
                                }
                                else{
                                    for(Agendamento ag : ws.agenda){
                                        if(ag.getCodAtt().equals(atend.getCodi())){
                                            minuto = ag.getAgMinuto()+dur;
                                            hora = ag.getAgHora();
                                            dia = ag.getDia()+1;
                                            mes = ag.getMes();
                                            if(minuto > 59){
                                                minuto = 00;
                                                hora = hora + 1;
                                                if(hora >= ws.pa.getMfh() && hora <= ws.pa.getTih()) hora = ws.pa.getTih();
                                                if(hora >= ws.pa.getTfh()){ hora = ws.pa.getMih(); dia = ag.getDia()+1;}
                                                if(mes>30) mes = 1;
                                            }
                                            writer.write("<p>Dia " + dia + "/" + mes
                                            + " às " + hora + ":" + minuto + ".");
                                        }
                                    }
                                }
                            }
                            
                            writer.append(usrPageEnd);
                            webPage = "page.html";
                            state = 31;
                            break;
                        }
                    }
                    
                    for(Atendente este : ws.attes) {
                        
                        atendente = este.logar(user, pass);
                        if(atendente!=null){
                            writer.write(attPageIni);
                            
                            writer.write("<h2> > "+este.getNome().toUpperCase()+"</h2><p>");
                            for(int i=0;i<ws.agenda.size();i++){
                                if(este.getCodi().equals(ws.agenda.get(i).getCodAtt())){
                                    writer.write("<p>Atendimento nº: " + i
                                            + "<br />Dia: " + ws.agenda.get(i).getDia()
                                            + "/" + ws.agenda.get(i).getMes()
                                            + "<br />Hora: " + ws.agenda.get(i).getAgHora()
                                            + ":" + ws.agenda.get(i).getAgMinuto()
                                            + "</p>");
                                }
                            }
                            
                            writer.append(attPageEnd);
                            webPage = "page.html";
                            state = 20;
                            break;
                        }
                    }
                }
                break;
            
            case 12:

                if(token.startsWith("?back") == true) {
                    webPage = "index.html";
                    state = 11;
                    break;
                }
                
                if(token.startsWith("?inim=") == true){
                    inim = token.substring(6);
                    inim = inim.replace("%3A",":");
                    token = tokenizedLine.nextToken();
                    endm = token.substring(5);
                    endm = endm.replace("%3A",":");
                    token = tokenizedLine.nextToken();
                    init = token.substring(5);
                    init = init.replace("%3A",":");
                    token = tokenizedLine.nextToken();
                    endt = token.substring(5);
                    endt = endt.replace("%3A",":");
                    token = tokenizedLine.nextToken();
                    temp = token.substring(5);
                    ws.pa.setPerDeAge(inim, endm, init, endt, temp);
                    ws.savePa();
                }

                if(token.startsWith("?anom=") == true){
                    nome = token.substring(6);
                    token = tokenizedLine.nextToken();
                    norg = token.substring(5);
                    token = tokenizedLine.nextToken();
                    user = token.substring(5);
                    token = tokenizedLine.nextToken();
                    pass = token.substring(5);
                    ws.attes.add(new Atendente(nome, norg, user, pass, 0));
                    n_att += 1;
                    ws.saveAttes();
                }

                writer.write(admPageIni);
                writer.write("<p>Perfil de atendimento atual:</p>"+ws.pa.toString());
                writer.append(admPageEnd);
                break;
                
            case 20:
                if(token.startsWith("?back") == true) {
                    webPage = "index.html";
                    state = 11;
                    break;
                }
                
                if(token.startsWith("?idat=") == true) {
                    // codigo do atendimetno
                    idat = Integer.parseInt(token.substring(6));
                    token = tokenizedLine.nextToken();
                    // usuario compareceu?
                    comp = token.substring(5).equals("sim");
                    token = tokenizedLine.nextToken();
                    // observação
                    obat = token.substring(5);
                    
                    for(int i=0;i<ws.agenda.size();i++){
                        if(i == idat){
                            ws.agenda.get(i).setComp(comp);
                            ws.agenda.get(i).setObs(obat);
                        }
                    }
                }
                
                writer.write(attPageIni);
                
                
                writer.write("<h2> > " + atendente.getNome().toUpperCase() + "</h2>");        
                for(int i=0;i<ws.agenda.size();i++){
                    if(i == idat){
                        if(atendente.getCodi().equals(ws.agenda.get(i).getCodAtt())){
                            writer.write("<p>Atendimento nº: " + i
                                    + "<br />Dia: " + ws.agenda.get(i).getDia()
                                    + "/" + ws.agenda.get(i).getMes()
                                    + "<br />Hora: " + ws.agenda.get(i).getAgHora()
                                    + ":" + ws.agenda.get(i).getAgMinuto()
                                    + "<br /> Compareceu:" + comp
                                    + "<br />Observações: " + obat
                                    +"</p>");
                        }
                    }
                }
                writer.append(attPageEnd);
                ws.saveAgenda();
                break;
                
            case 30:

                if(token.startsWith("?back") == true) {
                    webPage = "index.html";
                    state = 11;
                    break;
                }
                
                if(token.startsWith("?nome=") == true){
                    nome = token.substring(6);
                    token = tokenizedLine.nextToken();
                    norg = token.substring(5);
                    token = tokenizedLine.nextToken();
                    fone = token.substring(5);
                    token = tokenizedLine.nextToken();
                    mail = token.substring(5);
                    token = tokenizedLine.nextToken();
                    user = token.substring(5);
                    token = tokenizedLine.nextToken();
                    pass = token.substring(5);
                    ws.users.add(new Usuario(nome, norg, fone, mail, user, pass));
                    usuario = ws.users.get(ws.users.size()-1);
                    ws.saveUsers();

                    writer.write(usrPageIni);
                                                
                    if(ws.attes.isEmpty())
                        writer.write("<p>Não há atendentes disponíveis</p>");

                    else{
                        Atendente atend = ws.attes.get(0);
                        for(int i=0;i<ws.attes.size()-1;i++){
                            if(ws.attes.get(i).getAtendimentos() > ws.attes.get(i+1).getAtendimentos())
                                atend= ws.attes.get(i+1);                           
                        }
                        
                        if(ws.agenda.isEmpty()) {
                            writer.write("<p>Dia " + 2 + "/" + 1 
                                        + " às " + ws.pa.getMih() + ":" + ws.pa.getMim() + "</p>");
                        }
                        else{
                            for(Agendamento ag : ws.agenda){
                                if(ag.getCodAtt().equals(atend.getCodi())){
                                    minuto = ag.getAgMinuto()+dur;
                                    hora = ag.getAgHora();
                                    dia = ag.getDia()+1;
                                    mes = ag.getMes();
                                    if(minuto> 59){
                                        minuto = 00;
                                        hora = hora + 1;
                                        if(hora >= ws.pa.getMfh() && hora <= ws.pa.getTih()) hora = ws.pa.getTih();
                                        if(hora >= ws.pa.getTfh()){ hora = ws.pa.getMih(); dia = ag.getDia()+1;}
                                        if(mes>30) mes = 1;
                                    }
                                    writer.write("<p>Dia " + dia + "/" + mes
                                    + " às " + hora + ":" + minuto + ".");
                                }
                            }
                        }
                    }
                    
                    writer.append(usrPageEnd);
                    webPage = "page.html";
                    state = 31;
                }
                break;
                
            case 31:
                if(token.startsWith("?back") == true) {
                    webPage = "index.html";
                    state = 11;
                    break;
                }
                
                if(token.startsWith("?okay") == true) {
                    
                   writer.write(okaPageIni);

                   if(att_time >= (ws.attes.size() - 1))
                       att_time = 0;
                   else
                       att_time++;
                   
                    String atend = ws.attes.get(att_time).getCodi();
                   
                   if(ws.agenda.isEmpty()) {
                        hora = ws.pa.getMih();
                        minuto = ws.pa.getMim();
                        dia = 1;
                        mes = 1;
                   }
                   
                   else{
                       //ws.agenda.add(new Agendamento());
                       for(Agendamento ag : ws.agenda){
                           if(ag.getCodAtt().equals(atend)){
                               minuto = ag.getAgMinuto()+dur;
                               hora = ag.getAgHora();
                               dia = ag.getDia()+1;
                               mes = ag.getMes();
                               if(minuto > 59){
                                    minuto = 00;
                                    hora = hora + 1;
                                    if(hora >= ws.pa.getMfh() && hora <= ws.pa.getTih()) hora = ws.pa.getTih();
                                    if(hora >= ws.pa.getTfh()){ hora = ws.pa.getMih(); dia = ag.getDia()+1;}
                                    if(mes>30) mes = 1;
                               }
                           }
                       }
                   }
                   ws.agenda.add(new Agendamento(atend, usuario.getNorg(),hora,minuto,dia,mes));
                   writer.write("<p>Dia " + dia + "/" + mes
                                    + " às " + hora + ":" + minuto + ".</p>");
                    writer.append(okaPageEnd);
                    ws.saveAgenda();
                }
                break;

            default:
                webPage = "error.html";
                state = 10;
                break;
        }
        writer.close();

        File file = new File(webPage);

        int numOfBytes = (int) file.length();
        FileInputStream inFile = new FileInputStream(webPage);
        byte[] fileInBytes = new byte[numOfBytes];
        inFile.read(fileInBytes);

        outToClient.writeBytes ("HTTP/1.0 200 Document Follows\r\n");
        outToClient.writeBytes ("Content-Length: " + numOfBytes + "\r\n");
        outToClient.writeBytes ("\r\n");
        outToClient.write(fileInBytes, 0, numOfBytes);

        //connectionSocket.close();

        System.out.println("> Volta!");
        
    }

}}
