
import java.io.Serializable;


public class Atendente implements Serializable {
    
    private String nome;
    private String codi;
    private String user;
    private String pass;
    private int atendimentos;
    
    public Atendente (String nome, String codi, String user, String pass, int atendimentos) {
        
        this.nome = nome;
        this.codi = codi;
        this.user = user;
        this.pass = pass;
        this.atendimentos = atendimentos;
    }
    
    public String getNome() { return nome;}
    
    public String getCodi() { return codi;}
    
    public int getAtendimentos() { return atendimentos;}
    
    public void setAtendimentos(int atendimentos) {
        this.atendimentos = atendimentos;
    }
    
    public Atendente logar(String user, String pass) {

        if(this.user.equals(user)&&this.pass.equals(pass))
            return this;
        else
            return null;
    }
}
