
import java.io.Serializable;


public class PerfilDeAgendamento implements Serializable {
    
    private int m_ini_h;
    private int m_ini_m;
    private int m_fim_h;
    private int m_fim_m;
    private int t_ini_h;
    private int t_ini_m;
    private int t_fim_h;
    private int t_fim_m;
    private int a_dur_m;
    
    public PerfilDeAgendamento () {
        
        m_ini_h = 8;
        m_ini_m = 0;

        m_fim_h = 12;
        m_fim_m = 0;

        t_ini_h = 14;
        t_ini_m = 0;
        
        t_fim_h = 18;
        t_fim_m = 0;

        a_dur_m = 30;
    }
    
    public void setPerDeAge (String m_ini, String m_fim, String t_ini, String t_fim, String a_dur) {
        
        String str = m_ini.substring(0, 2);
        m_ini_h = Integer.parseInt(str);
        str = m_ini.substring(3, 5);
        m_ini_m = Integer.parseInt(str);
        
        str = m_fim.substring(0, 2);
        m_fim_h = Integer.parseInt(str);
        str = m_fim.substring(3, 5);
        m_fim_m = Integer.parseInt(str);
        
        str = t_ini.substring(0, 2);
        t_ini_h = Integer.parseInt(str);
        str = t_ini.substring(3, 5);
        t_ini_m = Integer.parseInt(str);
        
        str = t_fim.substring(0, 2);
        t_fim_h = Integer.parseInt(str);
        str = t_fim.substring(3, 5);
        t_fim_m = Integer.parseInt(str);
        
        str = a_dur.substring(0, 2);
        a_dur_m = Integer.parseInt(str);
    }

    public String toString() {
        
        return "<p>Turno da manhã: <br> Início: "+m_ini_h+" horas e "+m_ini_m+" minutos. "+
                " Fim: "+m_fim_h+" horas e "+m_fim_m+" minutos. <br>"+
                "Turno da tarde: <br> Início: "+t_ini_h+" horas e "+t_ini_m+" minutos. "+
                " Fim: "+t_fim_h+" horas e "+t_fim_m+" minutos.<br>"+
                "Duração do atendimento: "+a_dur_m+" minutos.</p>";
    }
    
    public int getMih() { return m_ini_h;}
    public int getMim() { return m_ini_m;}
    public int getMfh() { return m_fim_h;}
    public int getMfm() { return m_fim_m;}
    public int getTih() { return t_ini_h;}
    public int getTim() { return t_ini_m;}
    public int getTfh() { return t_fim_h;}
    public int getTfm() { return t_fim_m;}
    public int getAdm() { return a_dur_m;}
}
