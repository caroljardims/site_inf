
import java.io.Serializable;


public class Agendamento implements Serializable {
    
    private String cod_att;
    private String cod_usu;
    private String obs;
    private boolean comp;
    private int hora;
    private int minuto;
    private int dia;
    private int mes;
    
    public Agendamento () {}
    public Agendamento (String cod_att, String cod_usu, int hora, int minuto, int dia, int mes) {
        this.cod_att = cod_att;
        this.cod_usu = cod_usu;
        this.hora = hora;
        this.minuto = minuto;
        this. dia = dia;
        this.mes = mes;
    }
    
    public void setCodAtt(String cod_att){ this.cod_att = cod_att;}
    public void setCodUsu(String cod_usu){ this.cod_usu = cod_usu;}
    public void setObs(String obs){ this.obs = obs;}
    public void setComp(boolean comp){ this.comp = comp;}
    public void setHora(int hora){ this.hora = hora;}
    public void setMinuto(int minuto){ this.minuto = minuto;}
    public void setDia(int dia){ this.dia = dia;}
    public void setMes(int mes){ this.mes = mes;}
    
    public String getCodAtt(){return cod_att;}
    public String getCodUsu(){return cod_usu;}
    public String getObs(){return obs;}
    public boolean getComp(){return comp;}
    public int getAgHora(){return hora;}
    public int getAgMinuto(){return minuto;}
    public int getDia(){return dia;}
    public int getMes(){return mes;}
    
}
