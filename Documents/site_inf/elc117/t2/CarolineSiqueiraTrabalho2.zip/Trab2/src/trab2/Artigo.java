/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package trab2;

/**
 *
 * @author caroline
 */
public class Artigo extends Proposta{
    private String tipo;
    
    public Artigo() {
    }
    
    public void setArtigo(String tipo) {
        this.tipo = tipo;
    }
    
    public String getArtigo(){
        return tipo;
    }
    
    @Override
    public void mostra(){        
        System.out.println("Aluno: " + this.getAluno());
        System.out.println("Proposta ID: " + this.getNID());
        System.out.println("Topico: " + this.getTopico());
        if("Curto".equals(tipo))
            System.out.println("Artigo curto (4 páginas)");
        if("Longo".equals(tipo))
            System.out.println("Artigo longo (8 páginas)");
        System.out.println("Titulo: " + this.getTitulo());
        System.out.println("Resumo: " + this.getResumo());
        System.out.println("Autores:");
        this.mostraAutores();        
        System.out.println("Media:" + this.getMedia());
    }
    
    @Override
    public String imprime(){
        String proposta = "__Artigo__\n"
                + "Aluno: " + this.getAluno() + "\n"
                + "Proposta ID: " + this.getNID() + "\n"
                + "Topico: " + this.getTopico() + "\n"
                + "Artigo: " + this.tipo + "\n"
                + "Titulo: " + this.getTitulo() + "\n"
                + "Resumo: " + this.getResumo() + "\n"
                + "Autores: " + this.getAutores().toString() + "\n"
                + "Media: " + this.getMedia() + "\n";
        
        return proposta;
    }
}
