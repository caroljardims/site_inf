package trab2;

import java.util.ArrayList;
/**
 *
 * @author caroline
 */

/**
 *
 * @author caroline
 */
public class Proposta {
    private int nID;
    private String topico;
    private String aluno;
    private String titulo;
    private String resumo;
    private ArrayList<String> autores;
    private final ArrayList<Float> nota;
    private float media;    
    
    public Proposta(){
        autores = new ArrayList<String>();
        nota = new ArrayList<Float>();
    }
    public Proposta(int nID, String aluno, String titulo, String resumo, ArrayList<String> autores){
        this.nID = nID;
        this.aluno = aluno;
        this.titulo = titulo;
        this.resumo = resumo;
        this.autores = autores;
        nota = new ArrayList<Float>();
    }
    
    public void setAluno(String nome){
        this.aluno = nome;
    }
    
    public void setTopico(String topico){
        this.topico = topico;
    }
    
    public void setTitulo(String titulo){
        this.titulo = titulo;
    }
    
    public void setResumo(String resumo){
        this.resumo = resumo;
    }
    
    public void setAutores(ArrayList<String> autores){
        this.autores = autores;
    }
    
    public void setNID(int nID){
        this.nID = nID;
    }
    
    public void setNota(float nota){
        this.nota.add(nota);
    }

    public void setMedia(){
        for(int i=0; i< this.nota.size(); i++){
            this.media += this.nota.get(i);
        }
        this.media /= this.nota.size();
    }
    
    public String getAluno(){
        return aluno;
    }
    
    public String getTopico(){
        return topico;
    }
    
    public String getTitulo(){
        return titulo;
    }
    
    public String getResumo(){
        return resumo;
    }
    
    public ArrayList<String> getAutores(){
        return autores;
    }
    
    public void mostraAutores(){
        for(int i=0; i< this.autores.size();i++)
            System.out.println(this.autores.get(i));
    }
    
    public int getNID(){
        return nID;
    }
    
    public ArrayList getNota(){
        return nota;
    }
    public float getMedia(){
        return media;
    }
    
    public void mostra(){        
        System.out.println("Aluno: " + aluno);
        System.out.println("Proposta ID: " + nID);
        if(topico!=null) System.out.println("Topico: " + topico);
        System.out.println("Titulo: " + titulo);
        System.out.println("Resumo: " + resumo);
        this.mostraAutores();
        System.out.println("Media:" + media);
    }

    String imprime() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
