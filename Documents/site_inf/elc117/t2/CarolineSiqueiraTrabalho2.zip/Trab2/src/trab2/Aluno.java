package trab2;

import java.util.ArrayList;
/**
 *
 * @author caroline
 */
public class Aluno extends Usuario {
    private Artigo submeterArtigo;
    private MiniCurso submeterMiniCurso;
    
    public Aluno() {}
    
    public void subemeteArtigo(String tipo,  String titulo, String resumo, ArrayList<String> autores, String topico){
        this.submeterArtigo.setAluno(this.getNome());
        this.submeterArtigo.setArtigo(tipo);
        this.submeterArtigo.setTitulo(titulo);
        this.submeterArtigo.setResumo(resumo);        
        this.submeterArtigo.setAutores(autores);
        this.submeterArtigo.setTopico(topico);
    }
}
