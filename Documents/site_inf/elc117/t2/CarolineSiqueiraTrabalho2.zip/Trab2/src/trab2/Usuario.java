package trab2;

import java.util.ArrayList;

/**
 *
 * @author caroline
 */
class Usuario {
    protected String nome;
    protected int cod;
    protected ArrayList recebeID;
    
    public Usuario() {}
    public Usuario(String nome){
        this.nome = nome;
    }
    public Usuario(String nome, int cod){
        this.nome = nome;
        this.cod = cod;
    }
    
    public void setNome(String nome){
        this.nome = nome;
    }
    
    public void setCod(int cod){
        this.cod = cod;
    }

    public String getNome(){
        return nome;
    }
    
    public int getCod(){
        return cod;
    }
    
    public int getRecebeID(int i){
        return Integer.parseInt((String) recebeID.get(i));
    }
    
    public void showNome(){
        System.out.println(this.nome);
    }
    
    public void showCod(){
        System.out.println(this.cod);
    }
}