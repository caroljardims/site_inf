package trab2;

/**
 *
 * @author caroline
 */
public class TopicoInteresse {
    private String topico;
    
    public TopicoInteresse() {}
    public TopicoInteresse(String topico) {
        this.topico = topico;
    }
    
    public void setTopico(String topico){
        this.topico = topico;
    }
    
    public String getTopico(){
        return topico;
    }
}
