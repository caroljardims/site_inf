package trab2;

import java.util.ArrayList;

/**
 *
 * @author caroline
 */
public class Organizador {
    private final ArrayList<Proposta> proposta;
    
    public Organizador() {
       this.proposta = new ArrayList<Proposta>();
    }
    
    public Avaliador adicionarAvaliador(Avaliador avaliador){
        return avaliador;
    }
    
    public TopicoInteresse adicionarTopico(TopicoInteresse topico){
        return topico;
    }
    
    public void adicionarProposta(Proposta proposta){
        this.proposta.add(proposta);
    }
    
    public void rankingProposta(){
        ArrayList<Proposta> ranking = this.proposta;
        while(!ranking.isEmpty()){
            float nota = 0;
            int index = 0;
            for(int i=0; i< ranking.size(); i++){
                if(ranking.get(i).getMedia() > nota){
                    nota = ranking.get(i).getMedia();
                    index = i;
                }
            }
            ranking.get(index).mostra();
            ranking.remove(index);
        }
    }
}
