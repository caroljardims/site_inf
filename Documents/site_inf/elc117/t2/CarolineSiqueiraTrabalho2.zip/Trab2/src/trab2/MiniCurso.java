/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package trab2;

/**
 *
 * @author caroline
 */
public class MiniCurso extends Proposta{
    private int vagas;
    private String material;
    
    public MiniCurso() {}
    
    public void setVagas(int vagas){
        this.vagas = vagas;
    }
    
    public void setMaterial(String material){
        this.material = material;
    }
    
    public int getVagas(){
        return vagas;
    }
    
    public String getMaterial(){
        return material;
    }
    
    @Override
    public void mostra(){        
        System.out.println("Aluno: " + this.getAluno());
        System.out.println("Proposta ID: " + this.getNID());
        System.out.println("Topico: " + this.getTopico());
        System.out.println("Mini Curso");
        System.out.println("Vagas: "+ vagas);
        System.out.println("Material: "+ material);
        System.out.println("Titulo: " + this.getTitulo());
        System.out.println("Resumo: " + this.getResumo());
        System.out.println("Autores:");
        this.mostraAutores();
        System.out.println(this.getAutores());
        System.out.println("Media:" + this.getMedia());
    }
    
    @Override
    public String imprime(){
        String proposta = "__Mini Curso__\n"
                + "Aluno: " + this.getAluno() + "\n"
                + "Proposta ID: " + this.getNID() + "\n"
                + "Topico: " + this.getTopico() + "\n"
                + "Titulo: " + this.getTitulo() + "\n"
                + "Resumo: " + this.getResumo() + "\n"
                + "Autores: " + this.getAutores().toString() + "\n"
                + "Vagas: " + vagas + "\n"
                + "Material: " + material + "\n"
                + "Media: " + this.getMedia() + "\n";
        
        return proposta;
    }
}
