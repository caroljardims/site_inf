package trab2;

import java.util.ArrayList;

/**
 *
 * @author caroline
 */
public class Avaliador extends Usuario{
    
    protected ArrayList<Integer> proposta;
    
    public Avaliador(){
        this.proposta = new ArrayList<Integer>();
    }
    public Avaliador(String nome, int id) {
        this.setNome(nome);
        this.setCod(id);
        this.proposta = new ArrayList<Integer>();
    }
    
    public void setProposta(int proposta){
        this.proposta.add(proposta);
    }
}
