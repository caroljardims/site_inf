-- ------------------------------------ --
-- UNIVERSIDADE FEDERAL DE SANTA MARIA  --
-- CENTRO DE TECNOLOGIA                 --
-- BACHARELADO EM CIÊNCIA DA COMPUTAÇÃO --
-- PARADIGMAS DE PROGRAMAÇÃO            --
-- CAROLINE JARDIM SIQUEIRA             --
-- ------------------------------------ --

-- Questão 1.3

-- 1)
aumentaNum :: [Int] -> [Int]
aumentaNum [] = []
aumentaNum x = (((head x) * 2) + 12) : aumentaNum (tail x)

-- 2)
listaPar :: [Int] -> [Int]
listaPar [] = []
listaPar x 
	|(mod (head x) 2 == 0) = (head x) : listaPar (tail x)
	|otherwise = listaPar (tail x)

-- 3)
novaString :: [String] -> [String]
novaString [] = []
novaString x = ((head x) ++ ".") : novaString (tail x)

-- 4)
aplicaFunc :: [Int] -> [Int]
aplicaFunc [] = []
aplicaFunc x = ((head x)*(head x) + (head x)*2 + 1) : aplicaFunc (tail x)


-- 5)
qtdCaracter :: [String] -> [Int]
qtdCaracter [] = []
qtdCaracter x = (length (head x)) : qtdCaracter (tail x)

-- 6)
concatena :: [String] -> String
concatena [] = []
concatena x = (head x) ++ concatena (tail x)

-- 7)
maisQueCinco :: [String] -> [String]
maisQueCinco [] = []
maisQueCinco x 
	| (length (head x) > 5) = (head x) : maisQueCinco (tail x)
	|otherwise = maisQueCinco (tail x)

-- 8)
invertida :: [Int] -> [Int]
invertida [] = []
invertida (x:xs) = invertida xs ++ [x]

-- 9)
parString :: [String] -> [String] -> [String]
parString _[] = []
parString []_ = []
parString x y = ((head x) ++ (head y)) : parString (tail x) (tail y)

-- 10)
maisQuarentaEDois :: [Int] -> [Int] -> [Int]
maisQuarentaEDois [][] = []
maisQuarentaEDois _[] = []
maisQuarentaEDois []_ = []
maisQuarentaEDois x y = ((head x) + (head y) + 42) : maisQuarantaEDois (tail x) (tail y)





