#!/usr/bin/python
# -*- coding: iso-8859-1 -*-

# ------------------------------------ #
# UNIVERSIDADE FEDERAL DE SANTA MARIA  #
# CENTRO DE TECNOLOGIA                 #
# BACHARELADO EM CIÊNCIA DA COMPUTAÇÃO #
# PARADIGMAS DE PROGRAMAÇÃO            #
# CAROLINE JARDIM SIQUEIRA             #
# ------------------------------------ #

# Questão 1.2

import datetime
from datetime import date

def diasVencimento(x): return date.fromordinal(datetime.date(1997,10,07).toordinal() + int(x[40:44]))

#print diasVencimento("03399.51956.83700.000009.00852.401025.9.58330000198000")
