#!/usr/bin/python
# -*- coding: iso-8859-1 -*-

# ------------------------------------ #
# UNIVERSIDADE FEDERAL DE SANTA MARIA  #
# CENTRO DE TECNOLOGIA                 #
# BACHARELADO EM CIÊNCIA DA COMPUTAÇÃO #
# PARADIGMAS DE PROGRAMAÇÃO            #
# CAROLINE JARDIM SIQUEIRA             #
# ------------------------------------ #

# Questão 1.8

def formula(v,t,n): return [v/(1+t)^n for n in range(n)]

print formula(2,3,4)

''' 
Código em C

void formula (int v, int t, int n){
	int i, resultado;
	for(i=1;i<n;i++){
		resultado = v/(1+t)^n;
		printf(" %d", resultado);
	}
}

'''
