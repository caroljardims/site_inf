-- ------------------------------------ --
-- UNIVERSIDADE FEDERAL DE SANTA MARIA  --
-- CENTRO DE TECNOLOGIA                 --
-- BACHARELADO EM CIÊNCIA DA COMPUTAÇÃO --
-- PARADIGMAS DE PROGRAMAÇÃO            --
-- CAROLINE JARDIM SIQUEIRA             --
-- ------------------------------------ --

-- Questão 1.1

anoBissexto :: Int -> Bool
anoBissexto x = if ((mod x 100 /= 0) && (mod x 4 == 0)) || mod x 400 == 0 then True else False

-- Fonte: http://www.ask.com/question/how-to-calculate-leap-years
