-- ------------------------------------ --
-- UNIVERSIDADE FEDERAL DE SANTA MARIA  --
-- CENTRO DE TECNOLOGIA                 --
-- BACHARELADO EM CIÊNCIA DA COMPUTAÇÃO --
-- PARADIGMAS DE PROGRAMAÇÃO            --
-- CAROLINE JARDIM SIQUEIRA             --
-- ------------------------------------ --

-- Questão 1.7

-- Com recursão
inicial :: [String] -> [String]
inicial [] = []
inicial x
	|(head (head x)) == 'B' = (head x) : inicial (tail x)
	|otherwise = inicial (tail x)

-- Sem recursão
inicialB :: [String] -> [String]
inicialB x = filter(\x -> [head x] == "B") x

{-

-- Função em C

void inicialB(int tam, char **string)
  {
    int i;

    for(i=0;i<tam;i++)
      {
           if(string[i][0] == 'B')
	       puts(string[i]);
      }
  }

-}
