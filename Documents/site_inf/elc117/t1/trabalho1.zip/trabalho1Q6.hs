-- ------------------------------------ --
-- UNIVERSIDADE FEDERAL DE SANTA MARIA  --
-- CENTRO DE TECNOLOGIA                 --
-- BACHARELADO EM CIÊNCIA DA COMPUTAÇÃO --
-- PARADIGMAS DE PROGRAMAÇÃO            --
-- CAROLINE JARDIM SIQUEIRA             --
-- ------------------------------------ --

-- Questão 1.6

diferenteTreze :: String -> Bool
diferenteTreze x = if (length x == 13) then False else True

{- 

-- Função em C

int diferenteTreze(char string[]){
	int i = 0;
	int contador = 0;
	while(string[i] != '\0'){
		++contador;
	}
	++contador;
	if(contador == 13) return 0;
	return 1;
}

-}
