-- ------------------------------------ --
-- UNIVERSIDADE FEDERAL DE SANTA MARIA  --
-- CENTRO DE TECNOLOGIA                 --
-- BACHARELADO EM CIÊNCIA DA COMPUTAÇÃO --
-- PARADIGMAS DE PROGRAMAÇÃO            --
-- CAROLINE JARDIM SIQUEIRA             --
-- ------------------------------------ --

-- Questão 1.5

-- 1)
aumentaNum :: [Int] -> [Int]
aumentaNum x = map(\x -> (x*2)+12) x

-- 2)
listaPar :: [Int] -> [Int]
listaPar x = filter(\x -> mod x 2 == 0) x
