-- ------------------------------------ --
-- UNIVERSIDADE FEDERAL DE SANTA MARIA  --
-- CENTRO DE TECNOLOGIA                 --
-- BACHARELADO EM CIÊNCIA DA COMPUTAÇÃO --
-- PARADIGMAS DE PROGRAMAÇÃO            --
-- CAROLINE JARDIM SIQUEIRA             --
-- ------------------------------------ --

-- Questão 1.4

-- 1)
aumentaNum :: [Int] -> [Int]
aumentaNum x = map(\x -> (x*2)+12) x

-- 2)
listaPar :: [Int] -> [Int]
listaPar x = filter(\x -> mod x 2 == 0) x

-- 3)
novaString :: [String] -> [String]
novaString [] = []
novaString x = map (++".") [head x] ++ novaString(tail x)

-- 4)
aplicaFunc :: [Int] -> [Int]
aplicaFunc x = map(\x ->(x*x)+(2*x)+1) x

-- 5)
qtdCaracter :: [String] -> [Int]
qtdCaracter x = map(\x -> length x) x

-- 6)
concatena :: [String] -> String
concatena x = foldl1 (++) x

-- 7)
maisQueCinco :: [String] -> [String]
maisQueCinco x = filter(\x -> length x > 5) x

-- 8)
invertida :: [Int] -> [Int]
invertida x = reverse (x)

-- 9)
parString :: [String] -> [String] -> [String]
parString x y = zipWith (++) x y

-- 10)
maisQuarentaEDois :: [Int] -> [Int] -> [Int]
maisQuarentaEDois x y = zipWith (\x y -> (x+y+42)) x y
