class Ponto {

    private float pX;
    private float pY;
    private float dX;
    private float dY;
    private double distance;
    private float defaultPoint;
    
    public Ponto () {
        defaultPoint = 0; 
        pX = defaultPoint;
        pY = defaultPoint;
    }
    
    public Ponto (float x, float y) {
        defaultPoint = 0; 
        pX = x;
        pY = y;
    }
    
	public void desloc (float dx, float dy) {
	pX = pX + dx;
	pY = pY + dy;
    }
    
    public double dist (float x1, float y1) {
	dX = pX - x1;
	dY = pY - y1;
	distance = Math.sqrt(dX*dX + dY+dY);
	
	return distance;
    }
    
    public void print() {
        System.out.printf("\nPonto: (%.1f,%.1f) \nDeslocamento: (%.1f,%.1f) \nDistancia: %.1f\n\n",pX,pY,dX,dY,distance);
    }
}    

class PontoTest{

    public static void main(String[] args) {
	Ponto dot = new Ponto (4,4);
	dot.desloc(3,7);
	dot.dist(2,3);
	dot.print();
	
    }
}
