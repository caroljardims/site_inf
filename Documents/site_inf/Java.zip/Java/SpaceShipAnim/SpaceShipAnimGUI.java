/*
 * Classes for SpaceShip animation.
 */
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;
import javax.imageio.*;
import javax.swing.*;

class SpaceShipAnimGUI {
    
    public static void main(String[] args) {

        SpaceShip ship = new SpaceShip(0, 0);
        SpaceShipAnim anim = new SpaceShipAnim(ship);
        showGUI(anim);

    }
    
    private static void showGUI(SpaceShipAnim anim) {
        JFrame f = new JFrame("Animation");

        f.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        f.add(anim);
        f.pack();
        f.setVisible(true);
        anim.run();
    }
}

// A graphical view of a SpaceShip.
class SpaceShipView {

    BufferedImage img;
    SpaceShip ship;
    static final String filename = "spaceship-small.png";

    public SpaceShipView(SpaceShip ship) {
        this.ship = ship;
        this.img = readImage(filename);
        replaceColor(ship.getColor());
    }

    private BufferedImage readImage(String filename) {
        BufferedImage imgref = null;
        try {
            imgref = ImageIO.read(new File(filename));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return imgref;
    }

    public void draw(Graphics g) {
        g.drawImage(img, ship.getX(), ship.getY(), null);
    }

    // Replace the SpaceShip color.
    private void replaceColor(int c) {
        for (int i = 0; i < img.getHeight(); i++) {
            for (int j = 0; j < img.getWidth(); j++) {
                if (img.getRGB(j, i) == 0xfffb7df4) {
                    img.setRGB(j, i, c);
                }
            }
        }
    }
}

// A custom graphic component for SpaceShip animation.
class SpaceShipAnim extends Component {

    SpaceShipView view;
    SpaceShip ship;

    public SpaceShipAnim(SpaceShip ship) {
        this.ship = ship;
        view = new SpaceShipView(ship);
    }

    public void paint(Graphics g) {
        view.draw(g);
    }

    public Dimension getPreferredSize() {

        return new Dimension(600, 300);
    }

    public void run() {
        while (true) {
            ship.move();
            repaint();
            try {
                Thread.sleep(30);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}

