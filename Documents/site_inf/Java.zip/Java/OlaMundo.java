/** 
 * Esta classe implementa uma versao Java do programa que
 * imprime "Ola, mundo!" na saida padrao.
 */
class OlaMundo {
    public static void main(String[] args) {
        System.out.println("Ola, mundo!"); // imprime mensagem
	System.out.println("Numero de argumentos: "+args.length);
    }
}
